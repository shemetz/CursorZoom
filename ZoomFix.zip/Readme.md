# ZoomFix

FoundryVTT module to fix zooming - it will center around the cursor instead of around the center of the screen.

This does not affect PageUp, PageDown, or Numpad +/-. Those will still zoom into or out of the center of the screen. 

